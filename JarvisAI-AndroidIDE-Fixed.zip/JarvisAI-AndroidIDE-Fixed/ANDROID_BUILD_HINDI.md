# JARVIS AndroidIDE / Termux Build Guide

## क्या बदला
- Gradle 8.9 distribution configuration, `gradlew` bootstrap launcher, executable permission
- Camera intent improvement, recognition listener state safeguards, TTS package visibility
- Existing original UI, Kotlin source and permissions preserved

## जरूरी limitation
This ZIP was assembled without network access, so the official binary `gradle-wrapper.jar` **is NOT included**. `gradlew` is a custom bootstrap launcher that downloads Gradle 8.9 from the official distribution site on first use. This is NOT a standard Gradle wrapper and AndroidIDE may reject the missing wrapper JAR. To create the official wrapper on a system with Gradle 8.9 installed, run `gradle wrapper --gradle-version 8.9` inside the project; this generates `gradle/wrapper/gradle-wrapper.jar` and replaces the scripts. Do not claim the project was compiled or tested.

## AndroidIDE
1. Extract ZIP into Downloads or Documents.
2. Open AndroidIDE, configure Java 17 and Android SDK 35 if available.
3. Open project root `JarvisAI-AndroidIDE-Fixed` (folder containing settings.gradle.kts).
4. If it reports missing gradle-wrapper.jar, generate the official wrapper using a compatible Gradle installation, or use the Termux bootstrap instructions below.
5. Sync and run assembleDebug. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Termux alternative (requires Android SDK with platform 35, build-tools and Java 17)
`pkg update && pkg install openjdk-17 curl unzip`
`cd /sdcard/Download/JarvisAI-AndroidIDE-Fixed`
`sh gradlew assembleDebug`
You must configure ANDROID_HOME to a working Android SDK; Termux alone does not provide Android SDK/AGP-compatible aapt2 automatically. On ARM Android, Google Maven aapt2 binaries may require Android-compatible replacement, so builds can fail even with SDK installed.

## Security and limitations
- Wake word is phrase matching after speech recognition, not a dedicated low-power hotword engine.
- Android may stop background speech recognition and disallow background activity launches.
- No ChatGPT backend/API is included. No phone-wide privileged control.
- No APK was built or tested in this environment.
