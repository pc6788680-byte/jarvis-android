# JARVIS AI — Android prototype

## Features
- Original cyan futuristic animated HUD
- User-activated microphone foreground service with visible notification and Stop action
- Experimental Hindi speech recognition with 'Hey Jarvis' phrase detection
- Hindi text-to-speech
- Voice commands: time, camera, settings, Wi-Fi settings, dialer, alarms

## Build
1. Install Android Studio (on a PC) with Android SDK 35 and JDK 17.
2. Open the `JarvisAI` folder as a Gradle project. Allow Gradle sync (internet required).
3. Connect an Android 8+ phone with USB debugging or use an emulator with speech services.
4. Run the `app` configuration or use Build > Build APK(s).
5. Open the app, grant microphone permission, and tap ACTIVATE JARVIS while the app is visible.
6. Say 'Hey Jarvis time' or 'जार्विस कैमरा खोलो'. Tap STOP LISTENING or Stop in the notification to end the service.

## Important limitations
- This is source code, NOT a compiled APK. It has not been compiled or device-tested here.
- Android SpeechRecognizer is NOT designed for uninterrupted always-on recognition. This implementation attempts to restart sessions but may stop or be throttled, particularly with the screen off, battery optimizations, or vendor policies.
- Starting microphone foreground services from the background is restricted on modern Android. Start while the app is visible.
- Some Android versions block launching activities from background services. In those cases the app must be foregrounded or use a user-tapped notification.
- There is no ChatGPT/OpenAI API integration in this prototype. Never embed API keys directly in Android source; use a secure backend with authentication and rate limits.
- This is phrase recognition, not a low-power offline hotword detector. A production always-on wake word requires a dedicated wake-word engine and proper Android integration.
- Google speech services may require internet. Recognition availability and Hindi support depend on the device.
- Android Studio may suggest newer compatible Gradle/SDK versions. No Gradle wrapper is included; Android Studio can use installed Gradle or you can generate a wrapper.
- Microphone audio is processed by the installed recognition service according to its policies; do not assume fully offline/private recognition.
