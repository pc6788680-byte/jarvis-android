package com.example.jarvis

import android.app.*
import android.content.*
import android.os.*
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisService:Service(),RecognitionListener,TextToSpeech.OnInitListener {
 private var recognizer:SpeechRecognizer?=null
 private var tts:TextToSpeech?=null
 private val handler=Handler(Looper.getMainLooper())
 private var running=false
 private var speaking=false
 private var failures=0
 private var listening=false
 override fun onBind(intent:Intent?):IBinder?=null
 override fun onCreate(){super.onCreate();tts=TextToSpeech(this,this)}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  val channel=NotificationChannel("jarvis_listen","JARVIS listening",NotificationManager.IMPORTANCE_LOW)
  getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
  val stopIntent=Intent(this,JarvisService::class.java).apply { action="STOP" }
  if(intent?.action=="STOP"){stopSelf();return START_NOT_STICKY}
  val notification=Notification.Builder(this,"jarvis_listen").setContentTitle("JARVIS is listening")
   .setContentText("Microphone active • Tap to open JARVIS")
   .setSmallIcon(android.R.drawable.ic_btn_speak_now)
   .setContentIntent(PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE))
   .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stop",PendingIntent.getService(this,1,stopIntent,PendingIntent.FLAG_IMMUTABLE)).build()
  startForeground(101,notification);running=true;startListening();return START_NOT_STICKY
 }
 private fun startListening(){if(!running||speaking||listening)return
  if(!SpeechRecognizer.isRecognitionAvailable(this)){say("Speech recognition is unavailable on this phone");return}
  try{recognizer?.destroy();recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer?.setRecognitionListener(this)
   val request=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN")
    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)
   };recognizer?.startListening(request);listening=true
  }catch(e:Exception){retry()}
 }
 private fun retry(){listening=false;if(running){failures++;handler.postDelayed({startListening()},(1500L*failures.coerceAtMost(6)))}}
 override fun onResults(results:Bundle?){listening=false;failures=0;val heard=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();process(heard);if(!speaking)retry()}
 private fun process(heard:String){val s=heard.lowercase(Locale.ROOT)
  if(!s.contains("jarvis")&&!s.contains("जार्विस")&&!s.contains("जारविस"))return
  when {
   s.contains("time")||s.contains("समय")||s.contains("टाइम")->say("अभी समय है "+java.text.SimpleDateFormat("h:mm a",Locale.getDefault()).format(java.util.Date()))
   s.contains("camera")||s.contains("कैमरा")->launch(Intent("android.media.action.STILL_IMAGE_CAMERA"),"कैमरा खोल रहा हूँ")
   s.contains("setting")||s.contains("सेटिंग")->launch(Intent(Settings.ACTION_SETTINGS),"सेटिंग्स खोल रहा हूँ")
   s.contains("wifi")||s.contains("वाईफाई")->launch(Intent(Settings.ACTION_WIFI_SETTINGS),"वाई फाई सेटिंग्स खोल रहा हूँ")
   s.contains("dial")||s.contains("डायल")||s.contains("फोन")->launch(Intent(Intent.ACTION_DIAL),"डायलर खोल रहा हूँ")
   s.contains("alarm")||s.contains("अलार्म")->launch(Intent(AlarmClock.ACTION_SHOW_ALARMS),"अलार्म खोल रहा हूँ")
   else->say("जी, मैं सुन रहा हूँ। आप समय, कैमरा, सेटिंग्स, वाई फाई, डायलर या अलार्म बोल सकते हैं।")
  }
 }
 private fun launch(intent:Intent,message:String){intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  try{startActivity(intent);say(message)}catch(e:Exception){say("यह काम अभी नहीं हो पाया। ऐप खोलकर दोबारा कोशिश करें।")}
 }
 private fun say(message:String){speaking=true;listening=false;recognizer?.cancel();tts?.speak(message,TextToSpeech.QUEUE_FLUSH,null,"jarvis")
  handler.postDelayed({speaking=false;retry()},maxOf(2600L,message.length*100L))
 }
 override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS){tts?.language=Locale("hi","IN")}}
 override fun onReadyForSpeech(params:Bundle?){}
 override fun onBeginningOfSpeech(){}
 override fun onRmsChanged(rmsdB:Float){}
 override fun onBufferReceived(buffer:ByteArray?){}
 override fun onEndOfSpeech(){}
 override fun onError(error:Int){listening=false;retry()}
 override fun onPartialResults(partialResults:Bundle?){}
 override fun onEvent(eventType:Int,params:Bundle?){}
 override fun onDestroy(){running=false;handler.removeCallbacksAndMessages(null);recognizer?.destroy();tts?.stop();tts?.shutdown();super.onDestroy()}
}
