package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import kotlin.math.*

class MainActivity : Activity() {
 private lateinit var status: TextView
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(3,9,20)); setPadding(24,24,24,24) }
  val heading=TextView(this).apply { text="J.A.R.V.I.S  //  AI SYSTEM"; textSize=23f; setTextColor(Color.CYAN); gravity=Gravity.CENTER }
  root.addView(heading)
  root.addView(HudView(this),LinearLayout.LayoutParams(-1,0,1f))
  status=TextView(this).apply { text="SYSTEM READY • Wake word: Hey Jarvis"; textSize=15f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
  root.addView(status)
  val start=Button(this).apply { text="ACTIVATE JARVIS"; setOnClickListener { startAssistant() } }
  val stop=Button(this).apply { text="STOP LISTENING"; setOnClickListener { stopService(Intent(this@MainActivity,JarvisService::class.java)); status.text="SYSTEM OFFLINE" } }
  root.addView(start);root.addView(stop)
  val note=TextView(this).apply { text="Microphone stays active only while the foreground notification is shown. Keep this screen open when starting."; textSize=12f; setTextColor(Color.LTGRAY) }
  root.addView(note);setContentView(root)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),12)
 }
 private fun startAssistant(){ if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),11);return}; startForegroundService(Intent(this,JarvisService::class.java));status.text="LISTENING • Say Hey Jarvis" }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==11 && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) startAssistant()}
}
class HudView(context:android.content.Context):View(context){
 private val paint=Paint(3);private var phase=0f
 override fun onDraw(canvas:Canvas){super.onDraw(canvas);val cx=width/2f;val cy=height/2f;val r=min(width,height)*.32f
  paint.style=Paint.Style.STROKE;paint.strokeWidth=3f
  for(i in 0..5){paint.color=Color.argb(170-i*18,0,220,255);val radius=r*(.48f+i*.13f);canvas.drawCircle(cx,cy,radius,paint)}
  paint.strokeWidth=9f;paint.color=Color.CYAN
  for(i in 0..7){canvas.drawArc(cx-r,cy-r,cx+r,cy+r,phase+i*45f,23f,false,paint)}
  paint.style=Paint.Style.FILL;paint.color=Color.rgb(0,180,220);paint.textAlign=Paint.Align.CENTER;paint.textSize=35f;paint.typeface=Typeface.create(Typeface.MONOSPACE,Typeface.BOLD);canvas.drawText("JARVIS",cx,cy+12,paint)
  paint.textSize=13f;canvas.drawText("VOICE INTERFACE ONLINE",cx,cy+37,paint)
  phase=(phase+1.1f)%360f;postInvalidateDelayed(32)
 }
}
