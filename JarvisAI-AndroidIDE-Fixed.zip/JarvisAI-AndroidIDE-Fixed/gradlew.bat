@echo off
REM Bootstrap build script. Requires Gradle 8.9 installed on Windows.
where gradle >nul 2>nul || (echo Install Gradle 8.9 and add it to PATH & exit /b 1)
gradle %*
